function Get-GitStatus
{
    [CmdletBinding()]
    param ()

    git status
}
New-Alias -Name gstatus -Value Get-GitStatus -Force