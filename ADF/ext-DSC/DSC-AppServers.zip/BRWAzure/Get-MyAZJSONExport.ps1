function Get-MyAZJSONExport
{
    [CmdletBinding()]
    param (
        $rgName = 'ACU1-BRW-AOA-RG-S1',
        $Name = 'ACU1-BRW-AOA-S1-aks01',
        $type = 'Microsoft.ContainerService/managedClusters'
    )
    $ID = Get-MyAzResourceID -rgName $rgName -Name $Name -type $type

    $n = $type -split '/' | Select-Object -First 1
    $t = ($type -split '/' | Select-Object -Skip 1) -join '/'
    $API = Find-MYAZAPIVersion -ProviderNamespace $n -ResourceTypeName $t | Select-Object -First 1

    # full view and format output via json converersion
    Write-Verbose "Full view of resource, with latest API Version [$API]" -Verbose
    Invoke-AzRestMethod -Method GET -Path ($ID + "?api-version=$API") | 
        ForEach-Object Content | ConvertFrom-Json -Depth 20 | ConvertTo-Json -Depth 20
}

$scriptBlock = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameters)

    Get-AzResourceGroup | ForEach-Object ResourceGroupName | Where-Object {
        $_ -like "*$wordToComplete*"
    } | ForEach-Object {
        "'$_'"
    }
}

$scriptBlock2 = {
    param($commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameters)

    Get-AzResourceProvider | ForEach-Object ResourceTypes | ForEach-Object resourcetypename | Where-Object {
        $_ -like "*$wordToComplete*"
    } | ForEach-Object {
        "'$_'"
    }
}

Register-ArgumentCompleter -CommandName Get-MyAZJSONExport -ParameterName rgName -ScriptBlock $scriptBlock
Register-ArgumentCompleter -CommandName Get-MyAZJSONExport -ParameterName type -ScriptBlock $scriptBlock2