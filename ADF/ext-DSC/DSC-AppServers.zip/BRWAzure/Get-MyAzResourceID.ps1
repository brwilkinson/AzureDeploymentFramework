function Get-MyAzResourceID
{
    param (
        $rgName,
        $Name,
        $type,
        [validateset('providers', 'resources')]
        [string]$queryType = 'providers'
    )

    $n = $type -split '/' | Select-Object -First 1 | ForEach-Object { "/$_" }
    $t = ($type -split '/' | Select-Object -Skip 1) -join '/'
    $sub = Get-AzContext | ForEach-Object Subscription | ForEach-Object ID
    [string[]]$type = $t -split '/' | Where-Object { $_ } | ForEach-Object { "/$_" }
    if (! $type) { $type = $null, $null, $null }
    [string[]]$Names = $name -split '/' | Where-Object { $_ } | ForEach-Object { "/$_" }
    if (! $names) { $names = $null, $null, $null }
    '/subscriptions/{0}/resourceGroups/{1}/{2}{3}{4}{5}{6}{7}{8}{9}' -f $sub, $rgName, $queryType, $n, $type[0], $Names[0], $type[1], $Names[1], $type[2], $Names[2]
}

<#
# View the keyvault
$rgName = 'ACU1-BRW-AOA-RG-P0'
$Name = 'ACU1-BRW-AOA-P0-kvVLT01'
$type = 'Microsoft.KeyVault/vaults'

$ID = Get-MyAzResourceID -rgName $rgName -Name $Name -type $type
#>