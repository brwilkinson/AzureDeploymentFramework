function GitMerge
{
    param (
        [validateset('main','dev')]
        [string]$DestBranch = 'main',

        [string]$Message
    )

    [string]$SourceBranch = switch ($DestBranch)
    {
        'main' {'dev'}
        'dev' {'main'}
    }
    $message = $message ?? "Merge branch '$SourceBranch' into $DestBranch"

    git switch $DestBranch ; git pull ; git merge $SourceBranch -m $Message ; git push ; git switch $SourceBranch
}
