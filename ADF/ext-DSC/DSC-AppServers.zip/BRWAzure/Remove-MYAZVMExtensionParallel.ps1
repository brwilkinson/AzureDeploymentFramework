﻿Function Remove-MYAZVMExtensionParallel
{
    [cmdletbinding()]
    Param (
        [parameter(mandatory)]
        [String]$ResourceGroup,
    
        # The VM name to remove, regex are supported
        [parameter(mandatory)]
        [String]$VMName,

        # The Name/Type of Extension to remove, NB, these are user defined, so you need to update this list
        [validateset('DependencyAgent', 'Microsoft.Powershell.DSC', 'Microsoft.Powershell.DSC2', 'MonitoringAgent','SqlIaasExtension')]
        [String]$Extension,

        # The Script will not wait for the background jobs by default, use this switch to wait
        [Switch]$Wait,

        # Query the extension only, do not delete
        [Switch]$Query
    )

    # Remove the VM extension, that you specify, 
    $jobs = Get-AzVM -ResourceGroupName $ResourceGroup -Status | Where-Object Name -Match $VMName | ForEach-Object {
        $vm = $_
        
        Start-ThreadJob -ScriptBlock {
            
            Try
            {
                $resourceGroup = $using:Resourcegroup
                $VMName = $using:VM

                    if ($Using:Query)
                    {
                        Get-AzVMExtension -ResourceGroupName $ResourceGroup -VMName $VMName.name -Name $using:Extension -Status -ea Ignore |
                            Select-Object VMName, Name, ProvisioningState, @{n = 'extensionsstatus'; e = { $_.statuses.message } } | Format-Table -AutoSize
                    }
                    else
                    {
                        Remove-AzVMExtension -ResourceGroupName $resourceGroup -VMName $VMName.name -Name $using:Extension -Force -Verbose
                    }
            }
            Catch
            {
                Write-Warning -Message 'You must save your Context first [Save-AZContext -Path D:\ctx.json -Force]'
                Write-Warning $_
            }#Catch
        }#Start-Job
    }#Foreach-Object(Get-AZVM)

    Start-Sleep -Seconds 30
    $jobs | Receive-Job -Keep

    if ($Wait)
    {
        Start-Sleep -Seconds 30
        $jobs | Wait-Job | Receive-Job
    }
    else
    {
        Write-Warning "Run the following to view status of parallel delete`nGet-Job | Receive-Job -Keep"
    }
}#Function