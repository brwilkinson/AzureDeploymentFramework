function Start-MYAZPolicyEvaluation 
{
    param (
        [string]$Tenant = '72f988bf-86f1-41af-91ab-2d7cd011db47',
        [string]$Subscription = 'b8f402aa-20f7-4888-b45c-3cf086dad9c3',
        [string]$ResourceGroup,
        [int32]$SleepSeconds = 30
    )

    $AccessToken = Get-AzAccessToken | foreach token

    Write-Verbose $AccessToken -Verbose
    
    if ($ResourceGroup)
    {
        $RESOURCEID = "/subscriptions/$Subscription/$ResourceGroup"
    }
    else
    {
        $RESOURCEID = "/subscriptions/$Subscription"
    }

    $PostURI = "https://management.azure.com/$RESOURCEID/providers/Microsoft.PolicyInsights/policyStates/latest/triggerEvaluation?api-version=2018-07-01-preview"

    $Body = @{
        OutVariable     = 'Status'
        Method          = 'POST'
        UseBasicParsing = $true
        Headers         = @{
            Authorization  = "Bearer $($AccessToken)"
            'Content-Type' = 'application/json'
        }
    }

    $start = Get-Date
    Invoke-WebRequest -Uri $PostURI @Body

    $Body.Method = 'Get'
    $status[0].RawContent -split '\n' | Where-Object { $_ -match '(^Location: )(?<GetURL>https://.+)' }

    while ($Status[0].StatusCode -eq 202)
    {
        Start-Sleep -Seconds $SleepSeconds
        Invoke-WebRequest -Uri $Matches.GetURL @Body | Select-Object StatusCode, StatusDescription, Headers
        Write-Verbose -Message "Checking Policy in $SleepSeconds seconds"
    }
    $end = Get-Date
    [int32]$ts = New-TimeSpan -Start $Start -End $end | ForEach-Object TotalMinutes
    
    Write-Warning -Message "Policy update complete! in totalminutes: $ts"
}