function Stop-MYAZRGDP
{
    [cmdletbinding(SupportsShouldProcess)]
    param (
        [parameter(valuefrompipelinebyPropertyName)]
        [Sting]$ResourceGroupName,

        [parameter(valuefrompipelinebyPropertyName)]
        [alias('DP')]
        [String]$DeploymentName = '.',

        [validateset('Succeeded', 'Failed', 'Running')]
        [String]$DeploymentStatus
    )

    Get-MYAZResourceGroupDeployment -ResourceGroupName $ResourceGroupName | 
        Where-Object Name -Match "$DeploymentName" -OutVariable Deployment |
        Where-Object ProvisioningState -EQ $DeploymentStatus

    if ($PSCmdlet.ShouldProcess("Removing ResourceGroup Deployment: $($Deployment.Name)"))
    {
        #$Deployment | Remove-AzureRmResourceGroupDeployment -Verbose
        Write-Output deleting
    }#ShouldProcess
}

New-Alias -Name sprgd -Value Stop-MYAZRGDP -Force



