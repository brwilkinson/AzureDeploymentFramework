function Global:Switch-DSCModule
{
    param (
        [switch]$Core
    )

    $version = switch ($Core)
    {
        true { '2.0.5' }
        Default { '1.1' }
    }

    Get-Module -Name PSDesiredStateConfiguration -All | Remove-Module -Force
    Import-Module -Name PSDesiredStateConfiguration -RequiredVersion $version -PassThru -WarningAction:SilentlyContinue -Force -EA 0
}
Set-Alias -Name switchdsc -Value Switch-DSCModule -Force