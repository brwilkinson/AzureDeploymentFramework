function Global:Switch-DSCModule
{
    param (
        [switch]$Core
    )

    $version = switch ($Core)
    {
        true { '2.0.5' }
        Default { '1.1' }
    }

    echo $Version

    Get-Module -Name PSDesiredStateConfiguration -All | Remove-Module -Force
    Import-Module -Name PSDesiredStateConfiguration -MaximumVersion $version -PassThru -WarningAction:SilentlyContinue -Force -EA 0 -Verbose
}
Set-Alias -Name switchdsc -Value Switch-DSCModule -Force