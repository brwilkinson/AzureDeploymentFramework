function Global:Switch-DSCModule
{
    param (
        [switch]$Core
    )

    $version = switch ($Core)
    {
        true { '2.0.5' }
        Default { '1.1' }
    }

    Write-Output $Version
    Write-Verbose -Message "Import version [$version]" -Verbose
    Get-Module -Name PSDesiredStateConfiguration -All | Remove-Module -Force
    $Params = @{
        MaximumVersion = $version
        MinimumVersion = $Version
    }

    if ($version -eq '1.1' -and $IsCoreCLR)
    {
        $Params['UseWindowsPowerShell'] = $true
        # $Params['SkipEditionCheck'] = $true
    }

    Import-Module @Params -Name PSDesiredStateConfiguration -PassThru -Force -EA 0 -Global
}
Set-Alias -Name switchdsc -Value Switch-DSCModule -Force