﻿function Trace-MYAZDSCExtension
{
    Param (
        [String]$Enviro = 'S1',

        # The VM name, regex are supported
        [String]$VMName,

        [String]$Prefix = 'ACU1',

        [validateset('ADF', 'PSO', 'HUB', 'ABC', 'AOA')]
        [String]$App = 'ADF',

        [validateset('FNSV', 'FNFTE')]
        [String]$Tenant = 'FNFTE',
        
        [validateset('Script', 'scriptV2', 'Microsoft.Powershell.DSC', 'Microsoft.Powershell.DSC.Pull', 'Microsoft.Powershell.DSC.Push')]
        [String]$ExtensionName,
        
        [Int]$LoopTime = 10,

        [Int]$StatusView = 1,

        [switch]$NextAce
    )    

    while ($true)
    { 
        if ($NextAce)
        {
            $ExtensionName = 'Microsoft.Powershell.DSC.Push'
            $ResourceGroup = "$Prefix-$Enviro-$Tenant"
        }
        else
        {
            $ExtensionName = 'Microsoft.Powershell.DSC'
            $ResourceGroup = "$Prefix-BRW-$App-RG-$Enviro"
        }
        

        Get-AzVM -ResourceGroupName $ResourceGroup -Status | Where-Object Name -Match $VMName | ForEach-Object {
            Get-AzVMExtension -ResourceGroupName $ResourceGroup -Name $ExtensionName -VMName $_.Name -Status -ErrorAction silentlycontinue | 
                ForEach-Object substatuses | Select-Object -First $StatusView   ; Start-Sleep $LoopTime
        }
    }
}