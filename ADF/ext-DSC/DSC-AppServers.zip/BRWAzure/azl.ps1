function azl
{
    param(
        [validateset('MSFT', 'MSDN')]
        [String]$Account,
        [Switch]$auth
    )

    $AZ = Switch ($Account)
    {
        'MSFT'
        {
            @{ 
                Name     = 'Microsoft Azure Internal Consumption'
                Id       = 'b8f402aa-20f7-4888-b45c-3cf086dad9c3'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'MSDN'
        {
            @{ 
                Name     = 'Windows Azure MSDN - Visual Studio Ultimate'
                Id       = '1f0713fe-9b12-4c8f-ab0c-26aba7aaa3e5'
                TenantId = '3254f91d-4657-40df-962d-c8e6dad75963'
                State    = 'Enabled'
            }
        }
    }

    if ($Account)
    {
        if ($Auth)
        {
            Add-AzAccount -TenantId $AZ.TenantId -SubscriptionId $AZ.ID
        }
        else
        {
            Select-AzSubscription -Tenant $AZ.TenantId -SubscriptionId $AZ.ID
        }
    }
    else
    {
        Get-AzContext
    }
}