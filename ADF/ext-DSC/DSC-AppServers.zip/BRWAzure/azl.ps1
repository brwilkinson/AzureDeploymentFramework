function azl
{
    param(
        [validateset('SCE-AKS', 'SCE-APIM', 'MSFT', 'MSDN', 'HAA', 'FactoryMFG')]
        [String]$Account,
        [Switch]$auth
    )

    $AZ = Switch ($Account)
    {
        'FactoryMFG'
        {
            @{ 
                Name     = 'MSFT MDS SCE Factory MFG'
                Id       = '7aab1e63-3115-4365-89bc-bf1172dc93c9'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'SCE-AKS'
        {
            @{ 
                Name     = 'MSFT SCE SS Platform Prod1'
                Id       = '264614c3-e12f-4a52-8380-902410e8ac2d'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'SCE-APIM'
        {
            @{ 
                Name     = 'MSFT SCE APIM'
                Id       = '77196dc9-b5af-463b-b8de-f7e6232eae12'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'MSFT'
        {
            @{ 
                Name     = 'MSFT BENWILK AIRS'
                Id       = 'b8f402aa-20f7-4888-b45c-3cf086dad9c3'
                TenantId = '72f988bf-86f1-41af-91ab-2d7cd011db47'
                State    = 'Enabled'
            }
        }
        'MSDN'
        {
            @{ 
                Name     = 'Windows Azure MSDN - Visual Studio Ultimate'
                Id       = '1f0713fe-9b12-4c8f-ab0c-26aba7aaa3e5'
                TenantId = '3254f91d-4657-40df-962d-c8e6dad75963'
                State    = 'Enabled'
            }
        }
        'HAA'
        {
            @{ 
                Name     = 'HA App Labs'
                Id       = '855c22ce-7a6c-468b-ac72-1d1ef4355acf'
                TenantId = '11cb9e1b-bd08-4f80-bb8f-f71940c39079'
                State    = 'Enabled'
            }
        }
    }

    try
    {
        if ($Account)
        {
            if ($Auth)
            {
                $Params = @{
                    TenantId       = $AZ.TenantId
                    SubscriptionId = $AZ.ID
                    Outvariable    = 'result'
                    ErrorAction    = 'Stop'
                }
                if ($psversiontable.platform -eq 'Unix')
                {
                    $Params['UseDeviceAuthentication'] = $true
                }
                $Context = Add-AzAccount @Params | ForEach-Object Context
                $result
            }
            else
            {
                Select-AzSubscription -Tenant $AZ.TenantId -SubscriptionId $AZ.ID -OV Context -EA Stop
            }
            $env:AZAccount = "$Account/$($Context.account.Id.split('@')[0])"
        }
        else
        {
            Get-AzContext -ov Context -EA Stop
            $Name = $Context | ForEach-Object Subscription | ForEach-Object Name
            $env:AZAccount = "$Name/$($Context.account.Id.split('@')[0])"
        }
    }
    Catch
    {
        Write-Warning -Message $_
    }
}