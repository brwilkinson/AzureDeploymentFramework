function azlad
{
    param(
    )

    $t = Get-AzAccessToken -ResourceTypeName AadGraph
    $c = Connect-AzureAD -AadAccessToken $t.Token -AccountId $t.UserId

    Get-AzureADCurrentSessionInfo
}