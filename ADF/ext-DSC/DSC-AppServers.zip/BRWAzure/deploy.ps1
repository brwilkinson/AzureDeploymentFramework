function deploy
{
    param(
        [Parameter(Position=0)]
        [string]$TemplatePath,
        [Parameter(Position=1)]
        [string]$Enviro = 'T5',
        [string]$App = 'AOA',
        [validateset('RG','SUB','MG')]
        [string]$Scope,
        [string]$Location = 'centralus'
    )

    if ($Scope -eq 'RG')
    {
        New-AzResourceGroupDeployment -TemplateFile $TemplatePath -ResourceGroupName ACU1-BRW-${App}-RG-${Enviro} -verbose
    }
    elseif ($Scope -eq 'SUB')
    {
        New-AzDeployment -TemplateFile $TemplatePath -Location $Location -Verbose
    }
    elseif ($Scope -eq 'MG')
    {
        New-AzManagementGroupDeployment -TemplateFile $TemplatePath -Location $Location -Verbose -ManagementGroupId 11cb9e1b-bd08-4f80-bb8f-f71940c39079
    }
}