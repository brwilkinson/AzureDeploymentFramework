function deploy
{
    param(
        [Parameter(Position=0)]
        [string]$TemplatePath,
        [Parameter(Position=1)]
        [string]$Enviro
    )

    New-AzResourceGroupDeployment -TemplateFile $TemplatePath -ResourceGroupName ACU1-BRW-AOA-RG-${Enviro} -verbose
}