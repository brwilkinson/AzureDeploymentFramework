Function Get-MYAZDeploy
{
    Param(

        [parameter(mandatory)]
        [alias('DP')]
        [validateset('D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'P0', 'P1')]
        [string]$Deployment,

        [validateset('ADF', 'ATMOS')]
        [alias('App')]
        [string] $AppName = 'ATMOS-SB-DEV',

        [validateset('ADF', 'SPZE2')]
        [alias('PF')]
        [string] $Prefix = 'SPZE2',

        # Stop All deployments without confirmation or prompt
        [Switch]$Force
    )

    $ResourceGroupName = ($Prefix + '-' + $AppName + '-' + $Deployment)
    
    Get-AzResourceGroupDeployment -ResourceGroupName $ResourceGroupName | 
        Where-Object ProvisioningState -EQ 'Running' | Select-Object ProvisioningState, *Name, CorrelationId
    
}