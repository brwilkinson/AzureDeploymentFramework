﻿function Trace-MYAZDSCExtension
{
    Param (
        [String]$Enviro = 'D2',

        # The VM name, regex are supported
        [String]$VMName,

        [String]$Prefix = 'ACU1',

        [validateset('ADF', 'PSO', 'HUB', 'ABC', 'AOA', 'HAA')]
        [String]$App = 'AOA',
        
        [validateset('Script', 'scriptV2', 'Microsoft.Powershell.DSC2', 'Microsoft.Powershell.DSC', 'Microsoft.Powershell.DSC.Pull', 'Microsoft.Powershell.DSC.Push')]
        [String]$ExtensionName = 'Microsoft.Powershell.DSC2',
        
        [Int]$LoopTime = 10,

        [Int]$StatusView = 1,

        [switch]$VMSS
    )

    while ($true)
    {
        $ResourceGroup = "$Prefix-BRW-$App-RG-$Enviro"
        
        if ($VMSS)
        {
            Get-AzVmss -ResourceGroupName $ResourceGroup | Where-Object Name -Match $VMName | ForEach-Object {
                Get-AzVMSSExtension -ResourceGroupName $ResourceGroup -Name $ExtensionName -VMName $_.Name -Status -ErrorAction silentlycontinue | 
                    ForEach-Object substatuses | Select-Object -First $StatusView   ; Start-Sleep $LoopTime
                }
        }
        else
        {
            Get-AzVM -ResourceGroupName $ResourceGroup -Status | Where-Object Name -Match $VMName | ForEach-Object {
                Get-AzVMExtension -ResourceGroupName $ResourceGroup -Name $ExtensionName -VMName $_.Name -Status -ErrorAction silentlycontinue | 
                    ForEach-Object substatuses | Select-Object -First $StatusView   ; Start-Sleep $LoopTime
                }
        }
    }
}