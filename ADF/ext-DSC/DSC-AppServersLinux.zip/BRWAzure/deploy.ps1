function deploy
{
    param(
        [Parameter(Position=0)]
        [string]$TemplatePath,
        [Parameter(Position=1)]
        [string]$Enviro = 'T5',
        [string]$App = 'AOA',
        [validateset('RG','SUB','MG')]
        [string]$Scope = 'RG',
        [string]$Location = 'centralus',
        [string]$ParameterFile,
        [string]$ParameterObject
    )

    $Optional = @{}
    if ($ParameterFile)
    {
        $Optional['TemplateParameterFile'] = $ParameterFile
    }
    if ($ParameterObject)
    {
        $Optional['TemplateParameterObject'] = $ParameterObject
    }

    if ($Scope -eq 'RG')
    {
        New-AzResourceGroupDeployment -TemplateFile $TemplatePath -ResourceGroupName ACU1-BRW-${App}-RG-${Enviro} -verbose -ov out @Optional
    }
    elseif ($Scope -eq 'SUB')
    {
        New-AzDeployment -TemplateFile $TemplatePath -Location $Location -Verbose -ov out @Optional
    }
    elseif ($Scope -eq 'MG')
    {
        New-AzManagementGroupDeployment -TemplateFile $TemplatePath -Location $Location -Verbose -ManagementGroupId 11cb9e1b-bd08-4f80-bb8f-f71940c39079 -ov out @Optional
    }
    $global:result = $out.Outputs
}