# WVDDSC

PowerShell Web Access DSC __Class based Resource__

This is a DSC Resource for configuring Windows Virtual Destkop Host Pool (WVD)

__Requirements__
* PowerShell Version 5.0 +
* Server 2012 +
